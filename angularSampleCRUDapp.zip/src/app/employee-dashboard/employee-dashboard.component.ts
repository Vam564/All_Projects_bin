import { Component, OnInit } from '@angular/core';
import {FormBuilder, FormGroup} from '@angular/forms'
import { ApiService } from '../shared/api.service';
import { EmployeeModel } from './employee-dashboard.model';


@Component({
  selector: 'app-employee-dashboard',
  templateUrl: './employee-dashboard.component.html',
  styleUrls: ['./employee-dashboard.component.css']
})
export class EmployeeDashboardComponent implements OnInit {

  formValue !: FormGroup;
  employeeData !: any;
  showAdd !: boolean;
  showUpdate !: boolean;
  employeeModelObj : EmployeeModel = new EmployeeModel();
  constructor(private formbuilber: FormBuilder, 
    private api : ApiService) { }

  ngOnInit(): void {
    this.formValue = this.formbuilber.group({
      firstName:[''],
      lastName:[''],
      email:[''],
      mobile:[''],
      salary:['']
    })
    this.getAllEmployeeDetails()
  }

  clickAddUpdate(){
    this.formValue.reset()
    this.showAdd = true;
    this.showUpdate = false;
  }

  postEmployeeDetails(){
    console.log("Im inside this function post")
    this.employeeModelObj.firstName = this.formValue.value.firstName;
    this.employeeModelObj.lastName = this.formValue.value.lastName;
    this.employeeModelObj.email = this.formValue.value.email;
    this.employeeModelObj.mobile = this.formValue.value.mobile;
    this.employeeModelObj.salary = this.formValue.value.salary;

    this.api.postEmployee(this.employeeModelObj)
    .subscribe(res=>{
      console.log(res)
      alert('Employee added succesfully');
      let ref = document.getElementById('cancel')
      ref?.click()
      this.formValue.reset();
      this.getAllEmployeeDetails()
    },
    err=>{
      alert("Something went wrong");
    })
  }
 
  getAllEmployeeDetails(){
    this.api.getEmployee()
    .subscribe(res=>{
      this.employeeData = res;
    })
    console.log(this.employeeData)
  }

  delete_Employee(emp:any){
    console.log(emp.id)
    this.api.deleteEmployee(emp.id)
    .subscribe(res => {
      console.log("emp deleted succesfully")
      this.getAllEmployeeDetails()
    })
  }

  onEdit(emp: any){
    this.showAdd = false;
    this.showUpdate = true;
    this.employeeModelObj.id = emp.id
    this.formValue.controls['firstName'].setValue(emp.firstName)
    this.formValue.controls['lastName'].setValue(emp.lastName)
    this.formValue.controls['email'].setValue(emp.email)
    this.formValue.controls['mobile'].setValue(emp.mobile)
    this.formValue.controls['salary'].setValue(emp.salary)

  }

  updateEmployeeDetails(){
    this.employeeModelObj.firstName = this.formValue.value.firstName;
    this.employeeModelObj.lastName = this.formValue.value.lastName;
    this.employeeModelObj.email = this.formValue.value.email;
    this.employeeModelObj.mobile = this.formValue.value.mobile;
    this.employeeModelObj.salary = this.formValue.value.salary;

    this.api.updateEmployee(this.employeeModelObj, this.employeeModelObj.id)
    .subscribe(res=>{
      console.log("updated succesfully")
      this.getAllEmployeeDetails()
      let ref = document.getElementById('cancel')
      ref?.click()

    })
  }
}
